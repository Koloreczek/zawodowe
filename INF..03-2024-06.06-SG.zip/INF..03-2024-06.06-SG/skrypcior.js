function aktywujPole(pole){
    var pole1 = document.getElementById("blk1")
    var pole2 = document.getElementById("blk2")
    if (pole === "pole1"){
        pole1.style.visibility = 'block';
        pole2.style.visibility = 'hidden'
        pole3.style.visibility = 'hidden'
    }
    if (pole === "pole2"){
        pole1.style.visibility = 'block';
        pole3.style.visibility = 'hidden'
    }
}

function pobieraszdane(){
    imie = document.getElementById("imie").value;
    
    nazwisko = document.getElementById("nazwisko").value;

    console.log(witaj, imie, nazwisko);
}
