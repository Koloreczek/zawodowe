function obliczaj() {
    let wynik = document.getElementById("wynik");
    let cena = 0;

    const peeling = document.getElementById('peeling');
    const maskaw = document.getElementById('maska');

    const masaze = document.getElementById('masaz');

    const makijazz = document.getElementById('makijaz');

    if(peeling.checked) {
        cena = cena + 45;

    }

    if(maskaw.checked) {
        cena = cena + 30;
    }



    if(masaze.checked) {
        cena = cena + 20;

    }

    if(makijazz.checked) {
        cena = cena + 50;
    }

    wynik.innerHTML = "<p>Cena zabiegów: " + cena + "</p>";
}